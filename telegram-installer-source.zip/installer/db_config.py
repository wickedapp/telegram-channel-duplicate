MYSQL_CONFIG = {
    "host": "YOUR_HOST",
    "port": 3306,
    "user": "YOUR_USER",
    "password": "YOUR_PASSWORD",
    "database": "YOUR_DATABASE",
}
